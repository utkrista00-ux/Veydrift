# Landing assets

The starter ships no web font. Load the brand's families with `npm run font:add` (see AGENTS.md "Fonts").

- `placeholder.svg`: original neutral image placeholder. Replace it with the business's imagery during onboarding.
