// @polsia:user-owned

import { z } from 'zod';

const textField = (label: string, max: number) =>
  z.string().trim().min(1, `${label} is required`).max(max, `${label} is too long`);

const channel = z.string().trim().min(1, 'Channel cannot be empty').max(80, 'Channel is too long');

export const WorkspaceProfileCreate = z.object({
  businessName: textField('Business name', 120),
  market: textField('Market', 160),
  channels: z.array(channel).min(1, 'Add at least one channel').max(12, 'Use 12 channels or fewer'),
  hours: textField('Hours', 500),
  supportLanguage: textField('Support language', 80),
});

export const WorkspaceProfileItem = WorkspaceProfileCreate.extend({
  id: z.string(),
});

export const WorkspaceProfileGetResponse = z.object({
  profile: WorkspaceProfileItem.nullable(),
});

export const WorkspaceProfilePutResponse = z.object({
  profile: WorkspaceProfileItem,
});

export type WorkspaceProfileCreate = z.infer<typeof WorkspaceProfileCreate>;
export type WorkspaceProfileItem = z.infer<typeof WorkspaceProfileItem>;
export type WorkspaceProfileGetResponse = z.infer<typeof WorkspaceProfileGetResponse>;
export type WorkspaceProfilePutResponse = z.infer<typeof WorkspaceProfilePutResponse>;
