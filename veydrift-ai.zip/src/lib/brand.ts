// @polsia:user-owned — brand identity. Edit freely. `site.ts` re-exports
// siteName/siteDescription; `manifest.ts` + `opengraph-image.tsx` read `brandVisual`.

export const siteName = 'Veydrift';
export const siteDescription = 'Turn everyday social inquiries into completed orders.';

// PWA + social-share colors. HEX only (CSS variables aren't readable here) — set
// them to match the theme you define in src/app/brand-theme.css. The starter
// values are achromatic placeholders, not a palette.
export const brandVisual = {
  /** PWA browser-UI / status-bar color — usually your background or primary. */
  themeColor: '#c95b3d',
  /** PWA splash + install background. */
  backgroundColor: '#f7efe4',
  /** Social-share (OG/Twitter) image. */
  og: {
    background: '#f7efe4',
    foreground: '#3b211c',
    /** Second line under the site name; '' hides it. */
    tagline: 'Turn everyday social inquiries into completed orders.',
    /** Optional https PNG/JPEG background photo; '' keeps the plain-color card. */
    image: '',
  },
} as const;
