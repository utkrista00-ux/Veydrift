// @polsia:user-owned

import 'server-only';

import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import {
  WorkspaceProfileCreate,
  WorkspaceProfileGetResponse,
  WorkspaceProfilePutResponse,
} from '@/lib/contracts/workspace-profile';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

async function getSession() {
  return auth.api.getSession({ headers: await headers() });
}

export async function GET() {
  let session: Awaited<ReturnType<typeof getSession>>;
  try {
    session = await getSession();
  } catch {
    return NextResponse.json({ error: 'Unable to authenticate request' }, { status: 500 });
  }

  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const profile = await prisma.workspaceProfile.findUnique({
      where: { ownerId: session.user.id },
      select: {
        id: true,
        businessName: true,
        market: true,
        channels: true,
        hours: true,
        supportLanguage: true,
      },
    });

    return NextResponse.json(WorkspaceProfileGetResponse.parse({ profile }));
  } catch {
    return NextResponse.json({ error: 'Unable to load business profile' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  let session: Awaited<ReturnType<typeof getSession>>;
  try {
    session = await getSession();
  } catch {
    return NextResponse.json({ error: 'Unable to authenticate request' }, { status: 500 });
  }

  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const parsed = WorkspaceProfileCreate.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ errors: parsed.error.flatten().fieldErrors }, { status: 400 });
  }

  try {
    const profile = await prisma.workspaceProfile.upsert({
      where: { ownerId: session.user.id },
      create: { ownerId: session.user.id, ...parsed.data },
      update: parsed.data,
      select: {
        id: true,
        businessName: true,
        market: true,
        channels: true,
        hours: true,
        supportLanguage: true,
      },
    });

    return NextResponse.json(WorkspaceProfilePutResponse.parse({ profile }));
  } catch {
    return NextResponse.json({ error: 'Unable to save business profile' }, { status: 500 });
  }
}
