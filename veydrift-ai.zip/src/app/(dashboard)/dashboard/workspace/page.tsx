// @polsia:user-owned

import type { Metadata } from 'next';
import { WorkspaceProfileForm } from '@/components/custom/workspace-profile-form';

export const metadata: Metadata = {
  title: 'Business profile',
  description: 'Set the business context for your private Veydrift workspace.',
};

export default function WorkspaceProfilePage() {
  return (
    <div className="grid gap-6">
      <div>
        <p className="text-sm font-medium text-muted-foreground">Workspace setup</p>
        <h1 className="text-3xl font-semibold tracking-normal text-foreground">Business profile</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
          Keep the basics of your business in one place. You can update them whenever your offer or
          support setup changes.
        </p>
      </div>
      <WorkspaceProfileForm />
    </div>
  );
}
