// @polsia:user-owned — bespoke Veydrift marketing home.

import {
  ArrowDownRight,
  ArrowUpRight,
  Bot,
  Check,
  ChevronRight,
  CircleDot,
  Instagram,
  MessageCircle,
  ShoppingBag,
  Sparkles,
} from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { siteDescription, siteName } from '@/lib/brand';

export const metadata: Metadata = {
  title: { absolute: siteName },
  description: siteDescription,
  alternates: { canonical: '/' },
};

const contactEmail = 'veydrift-5vqagm@polsia.app';

const channelDetails = [
  {
    icon: Instagram,
    label: 'Instagram',
    text: 'Turn “price?” comments and DMs into a guided buying conversation.',
  },
  {
    icon: MessageCircle,
    label: 'WhatsApp',
    text: 'Answer delivery, sizing, payment and availability questions around the clock.',
  },
  {
    icon: Bot,
    label: 'Website chat',
    text: 'Help ready-to-buy visitors choose confidently before they leave the page.',
  },
];

const workflow = [
  {
    number: '01',
    title: 'Understand the ask',
    text: 'Veydrift picks up the repetitive questions your team sees every day and responds in the moment.',
  },
  {
    number: '02',
    title: 'Guide the choice',
    text: 'It recommends the right product, shares the details that matter, and qualifies real intent.',
  },
  {
    number: '03',
    title: 'Move it to order',
    text: 'It collects order information, confirms the next step, and follows up when a shopper goes quiet.',
  },
];

export default function HomePage() {
  return (
    <main className="overflow-hidden">
      <section className="relative border-b border-border" aria-labelledby="hero-heading">
        <div className="pointer-events-none absolute -right-40 -top-32 size-[28rem] rounded-full bg-primary/10 blur-3xl" />
        <div className="pointer-events-none absolute bottom-0 left-0 h-48 w-48 rounded-full bg-accent/60 blur-3xl" />

        <div className="relative mx-auto grid max-w-screen-xl gap-14 px-6 pb-20 pt-16 lg:grid-cols-[minmax(0,1.05fr)_minmax(25rem,0.95fr)] lg:items-center lg:gap-20 lg:px-10 lg:pb-28 lg:pt-24">
          <div className="max-w-3xl motion-safe:animate-in motion-safe:fade-in motion-safe:slide-in-from-bottom-3 duration-700">
            <div className="mb-7 flex items-center gap-3 text-sm font-medium text-muted-foreground">
              <span className="flex size-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                <Sparkles className="size-4" aria-hidden />
              </span>
              <span>AI sales follow-through for small businesses</span>
            </div>
            <h1
              id="hero-heading"
              className="max-w-3xl font-display text-display text-foreground sm:text-[4.8rem]"
            >
              The conversation is already happening.
              <span className="mt-2 block text-primary">Let it sell.</span>
            </h1>
            <p className="mt-7 max-w-xl text-body-lg text-muted-foreground">
              {siteDescription} Veydrift handles the questions, recommendations and follow-up that
              turn social attention into order-ready demand.
            </p>
            <div className="mt-9 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
              <Button
                asChild
                size="lg"
                className="h-12 rounded-full px-7 transition-transform duration-200 ease-out hover:-translate-y-0.5"
              >
                <Link href="#contact">
                  See if Veydrift fits
                  <ArrowUpRight aria-hidden />
                </Link>
              </Button>
              <Button asChild variant="link" className="h-auto px-0 text-foreground">
                <Link href="#how-it-works">
                  Follow the conversation
                  <ChevronRight aria-hidden />
                </Link>
              </Button>
            </div>
            <p className="mt-5 text-caption text-muted-foreground">
              For Nepali shops, local brands and growing international teams.
            </p>
          </div>

          <div className="relative lg:pt-8 motion-safe:animate-in motion-safe:fade-in motion-safe:slide-in-from-bottom-5 duration-700 delay-150">
            <div className="absolute -left-5 top-0 hidden h-24 w-px bg-primary/50 sm:block lg:-left-8" />
            <Card className="relative overflow-hidden border-primary/20 bg-card/90 shadow-xl backdrop-blur transition-shadow duration-300 hover:shadow-2xl">
              <div className="flex items-center justify-between border-b border-border px-5 py-4">
                <div className="flex items-center gap-3">
                  <span className="flex size-9 items-center justify-center rounded-full bg-primary/15 text-primary">
                    <Bot className="size-5" aria-hidden />
                  </span>
                  <div>
                    <p className="text-sm font-semibold">Veydrift sales agent</p>
                    <p className="text-caption text-muted-foreground">Always ready to answer</p>
                  </div>
                </div>
                <Badge variant="outline" className="gap-1.5 border-primary/30 text-primary">
                  <CircleDot className="size-3 fill-current" aria-hidden />
                  Live
                </Badge>
              </div>
              <CardContent className="space-y-4 p-5">
                <div className="max-w-[82%] rounded-r-2xl rounded-bl-2xl bg-muted p-4 text-sm text-muted-foreground">
                  <p className="mb-2 text-caption font-semibold uppercase tracking-[0.16em] text-foreground/60">
                    Customer · Instagram
                  </p>
                  “Which perfume is sweet but not too heavy? And do you deliver in Kathmandu?”
                </div>
                <div className="ml-auto max-w-[88%] rounded-l-2xl rounded-br-2xl bg-primary p-4 text-sm text-primary-foreground shadow-sm">
                  <p className="mb-2 text-caption font-semibold uppercase tracking-[0.16em] text-primary-foreground/70">
                    Veydrift · just now
                  </p>
                  “Try our soft vanilla blend — sweet, warm and easy to wear. It’s Rs. 2,400 with
                  Kathmandu delivery available. Shall I reserve one for you?”
                </div>
                <div className="flex items-center gap-3 border-t border-border pt-4 text-sm">
                  <span className="flex size-8 items-center justify-center rounded-full bg-accent text-accent-foreground">
                    <ShoppingBag className="size-4" aria-hidden />
                  </span>
                  <div>
                    <p className="font-medium">Order-ready lead captured</p>
                    <p className="text-caption text-muted-foreground">
                      Preference · location · next step
                    </p>
                  </div>
                  <Check className="ml-auto size-5 text-primary" aria-hidden />
                </div>
              </CardContent>
            </Card>
            <div className="absolute -bottom-5 -left-4 flex items-center gap-2 rounded-full border border-border bg-background px-4 py-2 text-xs font-medium text-muted-foreground shadow-lg sm:-left-8">
              <span className="size-2 rounded-full bg-primary" />
              Less replying. More selling.
            </div>
          </div>
        </div>
      </section>

      <section className="border-b border-border bg-muted/40" aria-label="Veydrift promise">
        <div className="mx-auto flex max-w-screen-xl flex-col gap-5 px-6 py-7 sm:flex-row sm:items-center sm:justify-between lg:px-10">
          <p className="max-w-xl text-sm font-medium text-foreground">
            Your marketing already creates demand. Veydrift helps you keep the sale moving when the
            inbox gets busy.
          </p>
          <div className="flex items-center gap-2 text-caption uppercase tracking-[0.16em] text-muted-foreground">
            <span className="size-2 rounded-full bg-primary" />
            Demand, answered
          </div>
        </div>
      </section>

      <section
        id="channels"
        className="mx-auto max-w-screen-xl px-6 py-section-lg lg:px-10"
        aria-labelledby="channels-heading"
      >
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.4fr] lg:gap-24">
          <div>
            <p className="text-caption font-semibold uppercase tracking-[0.22em] text-primary">
              Where it works
            </p>
            <h2
              id="channels-heading"
              className="mt-4 max-w-md font-display text-h2 text-foreground"
            >
              Meet customers wherever they start asking.
            </h2>
            <p className="mt-5 max-w-sm text-body text-muted-foreground">
              One sales rhythm across the places your customers already use — without asking you to
              rebuild your business around another dashboard.
            </p>
          </div>
          <div className="grid divide-y divide-border border-y border-border sm:grid-cols-3 sm:divide-x sm:divide-y-0">
            {channelDetails.map(({ icon: Icon, label, text }) => (
              <div key={label} className="group px-1 py-7 sm:px-6 sm:py-4">
                <Icon
                  className="size-6 text-primary transition-transform duration-200 ease-out group-hover:-translate-y-1"
                  aria-hidden
                />
                <h3 className="mt-6 font-display text-h4 text-foreground">{label}</h3>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="how-it-works" className="bg-muted/50" aria-labelledby="workflow-heading">
        <div className="mx-auto max-w-screen-xl px-6 py-section-lg lg:px-10">
          <div className="flex flex-col justify-between gap-7 border-b border-border pb-10 lg:flex-row lg:items-end">
            <div>
              <p className="text-caption font-semibold uppercase tracking-[0.22em] text-primary">
                The Veydrift rhythm
              </p>
              <h2
                id="workflow-heading"
                className="mt-4 max-w-2xl font-display text-h2 text-foreground"
              >
                From “How much?” to “Where should I deliver?”
              </h2>
            </div>
            <p className="max-w-sm text-sm leading-6 text-muted-foreground">
              A sales agent should do more than answer. It should make the next step obvious.
            </p>
          </div>
          <ol className="mt-10 grid gap-0 border-l border-primary/40 lg:grid-cols-3 lg:border-l-0 lg:border-t">
            {workflow.map((step, index) => (
              <li
                key={step.number}
                className="group relative border-b border-border py-8 pl-8 last:border-b-0 lg:border-b-0 lg:border-r lg:py-10 lg:pl-0 lg:pr-10 lg:first:border-l lg:first:pl-8"
              >
                <span className="absolute -left-[0.4rem] top-9 size-3 rounded-full border-2 border-background bg-primary lg:-top-[0.4rem] lg:left-8" />
                <p className="font-mono text-caption tracking-[0.2em] text-primary">
                  {step.number}
                </p>
                <h3 className="mt-6 font-display text-h3 text-foreground transition-colors duration-200 group-hover:text-primary">
                  {step.title}
                </h3>
                <p className="mt-4 max-w-xs text-sm leading-6 text-muted-foreground">{step.text}</p>
                {index === 2 && <ArrowDownRight className="mt-7 size-5 text-primary" aria-hidden />}
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section
        id="why"
        className="mx-auto max-w-screen-xl px-6 py-section-lg lg:px-10"
        aria-labelledby="why-heading"
      >
        <div className="grid gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-start lg:gap-24">
          <div>
            <p className="text-caption font-semibold uppercase tracking-[0.22em] text-primary">
              Why Veydrift
            </p>
            <h2 id="why-heading" className="mt-4 max-w-2xl font-display text-h2 text-foreground">
              Keep the demand you already worked hard to create.
            </h2>
            <p className="mt-6 max-w-xl text-body-lg text-muted-foreground">
              You should not need to be online for every product question to become a sale. Veydrift
              gives your business a consistent, helpful first response — then shows you what made
              people move.
            </p>
          </div>
          <Card className="border-border bg-card shadow-none">
            <CardContent className="p-0">
              {[
                'Answers repetitive questions without sounding repetitive',
                'Recommends products using your own offer and selling context',
                'Collects details for delivery, payment or cash on delivery',
                'Follows up with interested shoppers who did not buy yet',
                'Surfaces conversion patterns you can act on',
              ].map((item) => (
                <div
                  key={item}
                  className="flex items-start gap-4 border-b border-border p-5 last:border-b-0"
                >
                  <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary">
                    <Check className="size-3.5" strokeWidth={3} aria-hidden />
                  </span>
                  <p className="text-sm leading-6 text-card-foreground">{item}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </section>

      <section
        id="contact"
        className="mx-6 mb-20 overflow-hidden rounded-[2rem] bg-primary text-primary-foreground lg:mx-auto lg:max-w-screen-xl"
        aria-labelledby="contact-heading"
      >
        <div className="relative px-7 py-14 sm:px-12 sm:py-16 lg:px-20 lg:py-20">
          <div className="pointer-events-none absolute -right-16 -top-24 size-72 rounded-full border-[3rem] border-primary-foreground/10" />
          <div className="pointer-events-none absolute -bottom-32 right-24 size-56 rounded-full border border-primary-foreground/15" />
          <div className="relative max-w-2xl">
            <p className="text-caption font-semibold uppercase tracking-[0.22em] text-primary-foreground/70">
              Start with one conversation
            </p>
            <h2 id="contact-heading" className="mt-4 max-w-xl font-display text-h2">
              Your next order might already be in the inbox.
            </h2>
            <p className="mt-5 max-w-lg text-body-lg text-primary-foreground/80">
              Tell us what customers ask, where they ask it, and what you sell. We’ll help you see
              where an AI sales agent can take the repetitive work off your plate.
            </p>
            <Button
              asChild
              size="lg"
              variant="secondary"
              className="mt-8 h-12 rounded-full px-7 transition-transform duration-200 ease-out hover:-translate-y-0.5"
            >
              <Link href={`mailto:${contactEmail}`}>
                Talk to Veydrift
                <ArrowUpRight aria-hidden />
              </Link>
            </Button>
            <p className="mt-5 text-caption text-primary-foreground/65">{contactEmail}</p>
          </div>
        </div>
      </section>
    </main>
  );
}
