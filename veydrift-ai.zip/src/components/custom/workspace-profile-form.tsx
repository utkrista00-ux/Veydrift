// @polsia:user-owned

'use client';

import { useCallback, useEffect, useState } from 'react';
import { type FieldErrors, useForm } from 'react-hook-form';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { apiFetch } from '@/lib/api-client';
import {
  WorkspaceProfileCreate,
  WorkspaceProfileGetResponse,
  type WorkspaceProfileItem,
  WorkspaceProfilePutResponse,
} from '@/lib/contracts/workspace-profile';
import { applyServerErrors } from '@/lib/forms';

type FormValues = Omit<WorkspaceProfileCreate, 'channels'> & { channels: string };

const blankValues: FormValues = {
  businessName: '',
  market: '',
  channels: '',
  hours: '',
  supportLanguage: '',
};

function valuesFromProfile(profile: WorkspaceProfileItem): FormValues {
  return {
    businessName: profile.businessName,
    market: profile.market,
    channels: profile.channels.join('\n'),
    hours: profile.hours,
    supportLanguage: profile.supportLanguage,
  };
}

function fieldMessage(errors: FieldErrors<FormValues>, field: keyof FormValues) {
  return errors[field]?.message?.toString();
}

export function WorkspaceProfileForm() {
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ defaultValues: blankValues });

  const loadProfile = useCallback(async () => {
    setIsLoading(true);
    setLoadError(false);
    try {
      const response = await apiFetch('/api/workspace-profile', {
        schema: WorkspaceProfileGetResponse,
      });
      reset(response.profile ? valuesFromProfile(response.profile) : blankValues);
    } catch {
      setLoadError(true);
    } finally {
      setIsLoading(false);
    }
  }, [reset]);

  useEffect(() => {
    void loadProfile();
  }, [loadProfile]);

  async function onSubmit(values: FormValues) {
    const parsed = WorkspaceProfileCreate.safeParse({
      ...values,
      channels: values.channels
        .split(/\r?\n/)
        .map((channel) => channel.trim())
        .filter(Boolean),
    });

    if (!parsed.success) {
      applyServerErrors({ errors: parsed.error.flatten().fieldErrors }, setError);
      return;
    }

    try {
      const response = await apiFetch('/api/workspace-profile', {
        method: 'PUT',
        body: JSON.stringify(parsed.data),
        schema: WorkspaceProfilePutResponse,
      });
      reset(valuesFromProfile(response.profile));
      toast.success('Business profile saved');
    } catch (error) {
      const body = error instanceof Error ? error.cause : undefined;
      if (!applyServerErrors(body, setError)) {
        toast.error('Could not save your business profile');
      }
    }
  }

  if (isLoading) {
    return <p className="text-sm text-muted-foreground">Loading your business profile…</p>;
  }

  if (loadError) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Business profile unavailable</CardTitle>
          <CardDescription>We could not load your profile. Try again in a moment.</CardDescription>
        </CardHeader>
        <CardContent>
          <Button type="button" variant="outline" onClick={() => void loadProfile()}>
            Try again
          </Button>
        </CardContent>
      </Card>
    );
  }

  const inputProps = (field: keyof FormValues) => ({
    'aria-invalid': fieldMessage(errors, field) ? true : undefined,
    'aria-describedby': fieldMessage(errors, field) ? `${field}-error` : undefined,
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Your business profile</CardTitle>
        <CardDescription>
          Tell Veydrift what your business does so your workspace starts with the right context.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="grid gap-5" noValidate>
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="businessName">Business name</Label>
              <Input
                id="businessName"
                {...inputProps('businessName')}
                {...register('businessName')}
              />
              {fieldMessage(errors, 'businessName') && (
                <p id="businessName-error" role="alert" className="text-sm text-destructive">
                  {fieldMessage(errors, 'businessName')}
                </p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="market">Market</Label>
              <Input
                id="market"
                placeholder="e.g. handmade skincare in Kathmandu"
                {...inputProps('market')}
                {...register('market')}
              />
              {fieldMessage(errors, 'market') && (
                <p id="market-error" role="alert" className="text-sm text-destructive">
                  {fieldMessage(errors, 'market')}
                </p>
              )}
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="channels">Customer channels</Label>
            <Textarea
              id="channels"
              rows={4}
              placeholder={'Instagram\nWhatsApp'}
              {...inputProps('channels')}
              {...register('channels')}
            />
            <p className="text-xs text-muted-foreground">Add one channel per line.</p>
            {fieldMessage(errors, 'channels') && (
              <p id="channels-error" role="alert" className="text-sm text-destructive">
                {fieldMessage(errors, 'channels')}
              </p>
            )}
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="hours">Hours</Label>
              <Textarea
                id="hours"
                rows={4}
                placeholder="Mon–Fri, 9:00–17:00; Sat–Sun closed"
                {...inputProps('hours')}
                {...register('hours')}
              />
              {fieldMessage(errors, 'hours') && (
                <p id="hours-error" role="alert" className="text-sm text-destructive">
                  {fieldMessage(errors, 'hours')}
                </p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="supportLanguage">Support language</Label>
              <Input
                id="supportLanguage"
                placeholder="English"
                {...inputProps('supportLanguage')}
                {...register('supportLanguage')}
              />
              {fieldMessage(errors, 'supportLanguage') && (
                <p id="supportLanguage-error" role="alert" className="text-sm text-destructive">
                  {fieldMessage(errors, 'supportLanguage')}
                </p>
              )}
            </div>
          </div>

          <div className="flex flex-col gap-3 border-t border-border pt-5 sm:flex-row sm:items-center sm:justify-end">
            <Button type="submit" disabled={isSubmitting} className="w-full sm:w-auto">
              {isSubmitting ? 'Saving…' : 'Save profile'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
