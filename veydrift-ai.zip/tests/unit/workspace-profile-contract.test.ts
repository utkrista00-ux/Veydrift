import { describe, expect, it } from 'vitest';
import {
  WorkspaceProfileCreate,
  WorkspaceProfileGetResponse,
  WorkspaceProfilePutResponse,
} from '@/lib/contracts/workspace-profile';

describe('workspace profile contract', () => {
  it('requires values and trims accepted text', () => {
    expect(
      WorkspaceProfileCreate.safeParse({
        businessName: '  Veydrift  ',
        market: '  Local retail  ',
        channels: [' Instagram ', ' WhatsApp '],
        hours: ' Mon–Fri, 9:00–17:00 ',
        supportLanguage: ' English ',
      }),
    ).toMatchObject({
      success: true,
      data: {
        businessName: 'Veydrift',
        market: 'Local retail',
        channels: ['Instagram', 'WhatsApp'],
        hours: 'Mon–Fri, 9:00–17:00',
        supportLanguage: 'English',
      },
    });

    expect(
      WorkspaceProfileCreate.safeParse({
        businessName: ' ',
        market: '',
        channels: [],
        hours: ' ',
        supportLanguage: '',
      }).success,
    ).toBe(false);
  });

  it('limits channels to one through twelve non-empty values', () => {
    const base = {
      businessName: 'Veydrift',
      market: 'Retail',
      hours: 'Weekdays',
      supportLanguage: 'English',
    };

    expect(WorkspaceProfileCreate.safeParse({ ...base, channels: [''] }).success).toBe(false);
    expect(WorkspaceProfileCreate.safeParse({ ...base, channels: Array(13).fill('Channel') }).success).toBe(false);
  });

  it('allows the first-setup response to have no profile', () => {
    expect(WorkspaceProfileGetResponse.parse({ profile: null })).toEqual({ profile: null });
    expect(
      WorkspaceProfilePutResponse.safeParse({
        profile: {
          id: 'profile_1',
          businessName: 'Veydrift',
          market: 'Retail',
          channels: ['Instagram'],
          hours: 'Weekdays',
          supportLanguage: 'English',
        },
      }).success,
    ).toBe(true);
  });

  it('does not expose a caller-supplied tenant key in the write contract', () => {
    const parsed = WorkspaceProfileCreate.parse({
      businessName: 'Veydrift',
      market: 'Retail',
      channels: ['Instagram'],
      hours: 'Weekdays',
      supportLanguage: 'English',
      ownerId: 'another-owner',
    });

    expect(parsed).not.toHaveProperty('ownerId');
  });
});
